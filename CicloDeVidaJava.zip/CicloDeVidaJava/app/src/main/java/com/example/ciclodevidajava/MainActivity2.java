package com.example.ciclodevidajava;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView textoEmail, textoPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textoEmail = findViewById(R.id.correoElectronico);
        textoPassword = findViewById(R.id.clave);

        String sessionEmail = getIntent().getStringExtra("email");
        String sessionPassword = getIntent().getStringExtra("password");

        textoEmail.setText(sessionEmail);
        textoPassword.setText(sessionPassword);

    }
}